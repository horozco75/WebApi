﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace LoginWindows
{
    public partial class Login : Form
    {
        public SqlConnection con;
        public string constr, query, userName, Password;
        private SqlCommand com;
        private void connection()
        {
           constr= ConfigurationManager.ConnectionStrings["WinLogconn"].ConnectionString.ToString();
           
            con = new SqlConnection(constr);
            con.Open();
        }
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
           
            userName = textBox1.Text;
            Password = textBox2.Text;
           

            if (userName == "" && Password == "")
            {
                MessageBox.Show("Please Enter Login Id and Password");
            }
            else
            {
                connection();
                query = "dbo.Emplogin";
                com = new SqlCommand(query, con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@Usename", userName);
                com.Parameters.AddWithValue("@word", Password);
                //int usercount = (Int32)com.ExecuteScalar();

                int usercount = Convert.ToInt32(com.ExecuteScalar());
                //int usercount = (int)com.ExecuteScalar();

                //int usercount = (int)com.ExecuteScalar();
                //int usercount = com.ExecuteNonQuery();

                if (usercount == 1)
                //if (id == 1)
                {
                    this.Hide();
                    Main M1 = new Main(userName);
                    M1.Show();
                }
                else
                {
                    //Login Lg = new Login();
                    //Lg.Show();
                  
                    MessageBox.Show("LoginId or Password Is wrong");
                
                }
            }
           
        }
    }
}
