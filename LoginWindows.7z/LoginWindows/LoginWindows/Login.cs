﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace LoginWindows
{
    public partial class Login : Form
    {
        public SqlConnection con;
        public string constr, query, userName, Password;
        private SqlCommand com;

        private void btnSalir_Click(object sender, EventArgs e)
        {
            DialogResult res;
            res = MessageBox.Show("Realmente Desea Salir del sistema?", "Salir de LabMECH", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                this.Show();
            }
        }

        private void connection()
        {
           constr= ConfigurationManager.ConnectionStrings["WinLogconn"].ConnectionString.ToString();
           
            con = new SqlConnection(constr);
            con.Open();
        }
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
           
            userName = textBox1.Text;
            Password = textBox2.Text;
           

            if (userName == "" && Password == "")
            {
                MessageBox.Show("Please Enter Login Id and Password");
            }
            else
            {
                connection();
                query = "dbo.Emplogin";
                com = new SqlCommand(query, con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@Usename", userName);
                com.Parameters.AddWithValue("@word", Password);
                //int usercount = (Int32)com.ExecuteScalar();

                int usercount = Convert.ToInt32(com.ExecuteScalar());
                //int usercount = (int)com.ExecuteScalar();

                //int usercount = (int)com.ExecuteScalar();
                //int usercount = com.ExecuteNonQuery();

                if (usercount == 1)
                //if (id == 1)
                {
                    this.Hide();
                    Main M1 = new Main(userName);
                    M1.Show();
                }

                //else
                //{
                //    //Login Lg = new Login();
                //    //Lg.Show();

                //    MessageBox.Show("Credenciales Incorrectas!");

                //}

                else
                {
                    if (textBox1.Text.Trim().Equals(""))
                    {
                        //MessageBox.Show("Enter Your Usuario to Login", "Empty Username", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        MessageBox.Show("Escriba el Usuario para Login");
                    }
                    else if (textBox2.Text.Trim().Equals(""))
                    {
                        //MessageBox.Show("Enter Your Password to Login", "Empty Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        MessageBox.Show("Por Favor escriba su Password para Login");
                    }
                    else
                    {
                        //MessageBox.Show("This Username Or Password Doesn't Exists", "Wrong Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        MessageBox.Show("El Usuario y/o Password No existen!");
                    }


                }


            }
           
        }
    }
}
