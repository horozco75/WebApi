﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio
{
    //public static SqlConnection conexion = new SqlConnection(@"Server=HOROZCO\HOROZCO; DataBase=INSTITUTO; User id = Usuario;password=Sql123#admin;");
    //public static String conexion = "Data Source=HOROZCO\\HOROZCO; Initial Catalog=CXC; user id = Usuario; password = Sql123#admin;";

    public class DConexion
    {                   
        public static String conexion = "Data Source=HOROZCO\\HOROZCO; Initial Catalog=TEST;  user id = Usuario; password = Sql123#admin;";        
        public String ChequearConexion()
        {
            String mensaje = "";
            SqlConnection SqlConexion = new SqlConnection();

            try
            {
                SqlConexion.ConnectionString = DConexion.conexion;
                SqlConexion.Open();
                mensaje = "Y";
            }
            catch (Exception ex)
            {
                mensaje = ex.Message;
            }
            finally
            {
                SqlConexion.Close();
            }

            return mensaje;
        }
    }


}



