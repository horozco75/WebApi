﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

using Laboratorio;

namespace Laboratorio
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        //BaseDeDatos bd = new BaseDeDatos(); // No se esta utilizando en este momento el Dll de Conexion.


        DataTable table = new DataTable();
        SqlConnection SqlConexion = new SqlConnection();

        private void btnClear_Click(object sender, EventArgs e)
        {
             txtNombre.Clear();
             txtPass.Clear();
            txtNombre.Focus();

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            DialogResult res;
            res = MessageBox.Show("Realmente Desea Salir del sistema?", "Salir de LabMECH", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                this.Show();
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                //creando la conexion
                //SqlConnection miConecion = new SqlConnection(@"server=HOROZCO\HOROZCO; Initial Catalog=TEST; user id = Usuario; password = 123;  Integrated Security= true;");

                SqlConexion.ConnectionString = DConexion.conexion; //utilizando la clase de conexion 
                //abriendo conexion
                SqlConexion.Open();

                //abriendo conexion
                //miConecion.Open();


                // SqlCommand comando = new SqlCommand("select Nombre, Clave from Usuarios where Nombre = '" + txtNombre.Text + "'And clave = '" + txtPass.Text + "' ", SqlConexion);
                string Respuesta = "";

                //SqlCommand comando = new SqlCommand();
                //comando.Connection = SqlConexion;
                //comando.CommandText = "dbo.ValidaUser";
                //comando.CommandType = CommandType.StoredProcedure;

                //SqlParameter ParUsr = new SqlParameter();
                //ParUsr.ParameterName = "@User";
                //ParUsr.SqlDbType = SqlDbType.VarChar;
                //ParUsr.Size = txtNombre.Text.Length;
                //ParUsr.Value = txtNombre.Text;
                //comando.Parameters.Add(txtNombre.Text);

                //SqlParameter ParPass = new SqlParameter();
                //ParPass.ParameterName = "@Pass";
                //ParPass.SqlDbType = SqlDbType.VarChar;
                //ParPass.Size = txtPass.Text.Length;
                //ParPass.Value = txtPass.Text;
                //comando.Parameters.Add(txtPass.Text);


                //string query = "dbo.ValidaUser";   //stored procedure Name
                //SqlCommand com = new SqlCommand(query, SqlConexion);
                //com.CommandType = CommandType.StoredProcedure;
                //com.Parameters.AddWithValue("@User", txtNombre.Text.ToString());   //for username 
                //com.Parameters.AddWithValue("@Pass", txtPass.Text.ToString());  //for word

                //com.ExecuteNonQuery();
                //Respuesta = "Y";



                //string query = "dbo.ValidaUser";   //stored procedure Name
                //SqlCommand com = new SqlCommand(query, SqlConexion);
                //com.CommandType = CommandType.StoredProcedure;
                //com.Parameters.AddWithValue("@User", txtNombre.Text.ToString());   //for username 
                //com.Parameters.AddWithValue("@Pass", txtPass.Text.ToString());  //for password

                ////int usercount = (Int32)com.ExecuteScalar();// for taking single value
                ////int usercount = com.ExecuteNonQuery();// for taking single value
                ////string ReturnValue = com.ExecuteNonQuery().ToString();
                ////int returnValue = (int)Parameters.Value;

                //int resultID = Convert.ToInt32(com.ExecuteScalar());
                //if (Convert.ToInt32(resultID) == 0)
                ////{
                ////    Response.Redirect("hello.aspx");
                ////}


                ////if (usercount == 1)  // comparing users from table 
                //if (Convert.ToInt32(resultID) == 0)
                //{
                //    //Response.Redirect("Welcome.aspx");  //for sucsseful login
                //    this.lblMensaje.ForeColor = Color.White;
                //    lblMensaje.Text = "Bienvenidos a MECHNIKOV";

                //    Main frmPrincipal = new Main();
                //    frmPrincipal.StartPosition = FormStartPosition.CenterScreen;
                //    frmPrincipal.Show();//abriendo el formulario principal                   
                //    frmPrincipal.WindowState = FormWindowState.Normal;

                //    this.Hide();//esto sirve para ocultar el formulario de login
                //}
                //else
                //{
                //    SqlConexion.Close();
                //    //lblMensaje.Text = "Invalid User Name or Password";  //for invalid login
                //    this.lblMensaje.ForeColor = Color.Red;
                //    lblMensaje.Text = "Usuario y/o Password Incorrectos";
                //    this.txtPass.Focus();
                //}
                ///******************
                ////SqlConexion.Open();
                //SqlCommand sql_cmnd = new SqlCommand("ValidaUser", SqlConexion);
                //sql_cmnd.CommandType = CommandType.StoredProcedure;
                //sql_cmnd.Parameters.AddWithValue("@User", SqlDbType.NVarChar).Value = txtNombre.Text.ToString();
                //sql_cmnd.Parameters.AddWithValue("@Pass", SqlDbType.NVarChar).Value = txtPass.Text.ToString();
                ////sql_cmnd.Parameters.AddWithValue("@AGE", SqlDbType.Int).Value = age;
                //sql_cmnd.ExecuteNonQuery();
                //SqlConexion.Close();

                //*******************************

                //SqlCommand cmd = new SqlCommand("ValidaUser", SqlConexion);
                //cmd.CommandType = CommandType.StoredProcedure;
                //SqlParameter p1 = new SqlParameter("User", txtNombre.Text);
                //SqlParameter p2 = new SqlParameter("Pass", txtPass.Text);
                //cmd.Parameters.Add(p1);
                //cmd.Parameters.Add(p2);
                //SqlDataReader rd = cmd.ExecuteReader();
                //SqlConexion.Close();


                //SqlDataAdapter da = new SqlDataAdapter(cmd);
                //da.Fill(table);

                //if (table.Rows.Count == 1)
                //{
                //    this.Hide();
                //    if (table.Rows[0][3].ToString() == "Area")
                //    {
                //        this.lblMensaje.ForeColor = Color.White;
                //        lblMensaje.Text = "Bienvenidos a MECHNIKOV";

                //        Main frmPrincipal = new Main();
                //        frmPrincipal.StartPosition = FormStartPosition.CenterScreen;
                //        frmPrincipal.Show();//abriendo el formulario principal                   
                //        frmPrincipal.WindowState = FormWindowState.Normal;

                //        this.Hide();//esto sirve para ocultar el formulario de login
                //    }
                //    else if (table.Rows[0][3].ToString() == "Otra Cosa")
                //    {
                //        //SqlConexion.Close();
                //        //lblinfo.Text = "Invalid username or password.";
                //        this.lblMensaje.ForeColor = Color.Red;
                //        lblMensaje.Text = "Usuario y/o Password Incorrectos";
                //        this.txtPass.Focus();
                //    }
                //}
                //else
                //{ 

                //}

                //SqlConexion.Close();

                ////*******************
                //if (rd.HasRows)

                //{

                //    rd.Read();

                //    //lblMensaje.Text = "You are Authorized.";
                //    //if (table.Rows.Count == 1)
                //    //{
                //    //    if (table.Rows[0][3].ToString() == )
                //    //}
                //    //FormsAuthentication.RedirectFromLoginPage(username.Text, true);
                //    //Response.Redirect("securepage/SecurePage.aspx");


                //    this.lblMensaje.ForeColor = Color.White;
                //    lblMensaje.Text = "Bienvenidos a MECHNIKOV";

                //    Main frmPrincipal = new Main();
                //    frmPrincipal.StartPosition = FormStartPosition.CenterScreen;
                //    frmPrincipal.Show();//abriendo el formulario principal                   
                //    frmPrincipal.WindowState = FormWindowState.Normal;

                //    this.Hide();//esto sirve para ocultar el formulario de login



                //}

                //else

                //{
                //    SqlConexion.Close();
                //    //lblinfo.Text = "Invalid username or password.";
                //    this.lblMensaje.ForeColor = Color.Red;
                //    lblMensaje.Text = "Usuario y/o Password Incorrectos";
                //    this.txtPass.Focus();
                //}
                //**************






                //*************************************************************************
                //////ejecuta una instruccion de sql devolviendo el numero de las filas afectadas
                ////comando.ExecuteNonQuery();
                //DataSet ds = new DataSet();
                ////SqlDataAdapter da = new SqlDataAdapter(comando);
                //SqlDataAdapter da = new SqlDataAdapter(com);

                ////Llenando el dataAdapter
                //da.Fill(ds, "Usuarios");
                ////utilizado para representar una fila de la tabla q necesitas en este caso usuario
                //DataRow DR;
                //DR = ds.Tables["Usuarios"].Rows[0];

                ////da.Fill(table);


                ////evaluando que la contraseña y usuario sean correctos
                //if ((txtNombre.Text == DR["Nombre"].ToString()) || (txtPass.Text == DR["Clave"].ToString()))
                //{                      

                //    Main frmPrincipal = new Main();
                //    frmPrincipal.StartPosition = FormStartPosition.CenterScreen;
                //    frmPrincipal.Show();//abriendo el formulario principal                  


                //    //frmPrincipal.WindowState = FormWindowState.Maximized;
                //    //frmPrincipal.WindowState = FormWindowState.Minimized; 
                //    frmPrincipal.WindowState = FormWindowState.Normal;


                //    this.Hide();//esto sirve para ocultar el formulario de login
                //}


                ///****************************
                //SqlConexion.Open();
                SqlDataAdapter sda = new SqlDataAdapter("select Count(*) from Usuarios where Nombre ='" + txtNombre.Text + "' and clave ='" + txtPass.Text + "'", SqlConexion);
                // SqlCommand comando = new SqlCommand("select Nombre, Clave from Usuarios where Nombre = '" + txtNombre.Text + "'And clave = '" + txtPass.Text + "' ", SqlConexion);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows[0][0].ToString() == "1")

                {

                    //RR_Main rm = new RR_Main();
                    //rm.Show();
                    //this.Hide();

                    Main frmPrincipal = new Main();
                    frmPrincipal.StartPosition = FormStartPosition.CenterScreen;
                    frmPrincipal.Show();//abriendo el formulario principal
                   ////frmPrincipal.WindowState = FormWindowState.Normal;
                    this.Hide();//esto sirve para ocultar el formulario de login




                }
                else { MessageBox.Show("Usuario y/o Password Incorrectos"); }

                SqlConexion.Close();

            }

            catch
            {

                if (table.Rows.Count <= 0)
                {
                    //panel1.Height = 0;
                    this.lblMensaje.ForeColor = Color.White;
                    lblMensaje.Text = "Usuario y/o Password Incorrectos";

                    this.txtPass.Focus();


                }

            }

            finally
            {
                //this.miConecion.Close();
            }

            table.Clear();
        }
    }
}
