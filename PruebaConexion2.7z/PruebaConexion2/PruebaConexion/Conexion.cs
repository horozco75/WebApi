﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Laboratorio
{
    public class DConexion
    {
        //public static String conexion = "Data Source=HOROZCO; Initial Catalog=TEST;  user id = Usuario; password = 123;"; //HOME        
        public static String conexion = "Data Source=HOROZCO\\HOROZCO; Initial Catalog=TEST;  user id = Usuario; password = Sql123#admin;";  //DESA

        public String ChequearConexion()
        {
            String mensaje = "";
            SqlConnection SqlConexion = new SqlConnection();

            try
            {
                SqlConexion.ConnectionString = DConexion.conexion;
                SqlConexion.Open();
                mensaje = "Y";
            }
            catch (Exception ex)
            {
                mensaje = ex.Message;
            }
            finally
            {
                SqlConexion.Close();
            }

            return mensaje;
        }

    }

    class Conexion
    {
        SqlConnection cn;
        SqlCommand cmd;
        SqlDataReader dr;
        SqlDataAdapter da;
        DataTable dt;

        public Conexion()
        {
           try
           {
                //cn = new SqlConnection("Data Source=HOROZCO;Initial Catalog=TEST;user id = Usuario; password = 123;");  //Home
                cn = new SqlConnection("Data Source=HOROZCO\\HOROZCO;Initial Catalog=TEST;user id = Usuario; password = Sql123#admin;");  //Desa

                cn.Open();

           }
            catch(Exception ex)
           {
               MessageBox.Show("No se conecto con la base de datos: "+ex.ToString());
           }
        }

        public string insertar(string codusr, string destina, string paginas, string descripdocu, string elaborado, string firmado, string modoenvio, string observaciones, string lugararchivo )
        {
            string salida = "Si se inserto correctamente";
            try
            {
                //cmd = new SqlCommand("Insert into Documentos(Id,Nombre,Apellidos,FechaNacimiento) values(" + id+",'"+nombre+"','"+apellidos+"','"+fecha+"')",cn);
                //cmd.ExecuteNonQuery();
                //*****************************
                cmd = new SqlCommand("[dbo].[sp_guardar_documento]", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@codigoUsuario", SqlDbType.NVarChar).Value = codusr.ToString();
                cmd.Parameters.AddWithValue("@destinatario", SqlDbType.NVarChar).Value = destina.ToString();
                cmd.Parameters.AddWithValue("@cntpaginas", SqlDbType.NVarChar).Value = paginas.ToString();
                cmd.Parameters.AddWithValue("@descripdocumento", SqlDbType.NVarChar).Value = descripdocu.ToString();
                cmd.Parameters.AddWithValue("@elaboradopor", SqlDbType.NVarChar).Value = elaborado.ToString();
                cmd.Parameters.AddWithValue("@firmadopor", SqlDbType.NVarChar).Value = firmado.ToString();
                cmd.Parameters.AddWithValue("@modoenvio", SqlDbType.NVarChar).Value = modoenvio.ToString();
                cmd.Parameters.AddWithValue("@observaciones", SqlDbType.NVarChar).Value = observaciones.ToString();
                cmd.Parameters.AddWithValue("@lugararchivo", SqlDbType.NVarChar).Value = lugararchivo.ToString();              
                cmd.ExecuteNonQuery();



            }
            catch (Exception ex)
            {
                salida = "No se conecto: " + ex.ToString();
            }
            return salida;
        }

       

        public int documentoRegistrado(string id)
        {
            int contador = 0;
            try
            {
                cmd = new SqlCommand("Select * from Documentos where Id_Docto="+id+"", cn);
                dr = cmd.ExecuteReader();
                while(dr.Read())
                {
                    contador++;
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo consultar bien: "+ex.ToString());
            }
            return contador;
        }

        public void cargarDocumentos(DataGridView dgv)
        {
            try
            {
                da = new SqlDataAdapter("Select * from Documentos ORDER BY Id_Docto DESC", cn);
                dt = new DataTable();
                da.Fill(dt);
                dgv.DataSource = dt;
            }
            catch(Exception ex)
            {
                MessageBox.Show("No se pudo llenar el Datagridview: "+ex.ToString());
            }
        }       



    }
}
