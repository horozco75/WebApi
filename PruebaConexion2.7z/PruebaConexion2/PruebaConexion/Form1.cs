﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laboratorio
{
    public partial class Main : Form
    {
        Conexion c = new Conexion();
        public Main(string CodUser)
        {
            InitializeComponent();
            lbliduser.Text = CodUser;
        }

        private void RbInsertar_CheckedChanged(object sender, EventArgs e)
        {
            txtDest.Enabled = true;
            txtCntPag.Enabled = true;
            txtDescrip.Enabled = true;

            //if (string.IsNullOrWhiteSpace(txtDest.Text) ||  string.IsNullOrWhiteSpace(txtCntPag.Text) || string.IsNullOrWhiteSpace(txtDescrip.Text) || string.IsNullOrWhiteSpace(txtElabo.Text) || RbInsertar.Checked || string.IsNullOrWhiteSpace(txtFirma.Text) || picturefoto.Image == null)
            if (string.IsNullOrWhiteSpace(txtDest.Text) || string.IsNullOrWhiteSpace(txtCntPag.Text) || string.IsNullOrWhiteSpace(txtDescrip.Text) || string.IsNullOrWhiteSpace(txtElabo.Text) || RbInsertar.Checked || string.IsNullOrWhiteSpace(txtFirma.Text) )
            {
                MessageBox.Show("Favor de completar los campos");
                return;
            }




            dtpFecha.Enabled = true;
            BtnAgregar.Enabled=true;
            BtnEliminar.Enabled = false;
            BtnModificar.Enabled = false;


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //RbInsertar.Checked = true;
            //Conexion c = new Conexion();
            //c.cargarDocumentos(DgvDocumentos);

        }

        private void RbEliminar_CheckedChanged(object sender, EventArgs e)
        {
            txtDest.Enabled = true;
            txtCntPag.Enabled = false;
            txtDescrip.Enabled = false;
            dtpFecha.Enabled = false;
            BtnEliminar.Enabled = true;
            BtnAgregar.Enabled = false;
            BtnModificar.Enabled = false;
        }

        private void RbModificar_CheckedChanged(object sender, EventArgs e)
        {

            if (txtDest.Text.Length == 0)
            {
                label1.Text = "DESTINATARIO IS EMPTY";
            }

            BtnModificar.Enabled = true;
            BtnEliminar.Enabled = false;
            BtnAgregar.Enabled = false;
            txtDest.Enabled = true;
            txtCntPag.Enabled = true;
            txtDescrip.Enabled = true;
            dtpFecha.Enabled = true;

        }

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            //if (txtDest.Text.Length == 0 || txtCntPag.Text.Length == 0 || txtElabo.Text.Length == 0 || txtFirma.Text.Length == 0) 
            //{
            //    label1.Text = "CAMPOS DESTINATARIO, CANTIDAD PAGINAS, ELABORADO POR Y FIRMADO POR ESTAN VACIOS!";
            //}


            //if(c.documentoRegistrado(Convert.ToInt32(txtDest.Text))==0)
            if (txtDest.Text != "")
            {
                //MessageBox.Show(c.insertar(Convert.ToInt32(txtDest.Text),txtNombre.Text,txtApellidos.Text,dtpFecha.Text));
             MessageBox.Show(c.insertar(lbliduser.Text, txtDest.Text, txtCntPag.Text, txtDescrip.Text, txtElabo.Text, txtFirma.Text, txtModoEnv.Text, txtObserva.Text, txtLugarArchivo.Text ));
                c.cargarDocumentos(DgvDocumentos);
             txtDest.Text = "";
             txtCntPag.Text = "";
             txtDescrip.Text = "";


          }
          else
          {
                //MessageBox.Show("Imposible de regitrar, El registro ya existe");
                MessageBox.Show("Imposible de regitrar, consulte al Administrador");
            }
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            RbInsertar.Checked = true;
            Conexion c = new Conexion();
            c.cargarDocumentos(DgvDocumentos);
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            DialogResult res;
            res = MessageBox.Show("Realmente Desea Salir del sistema?", "Salir de LabMECH", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                this.Show();
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtCntPag.Clear();
            //txtPass.Clear();
            txtCntPag.Focus();
        }
    }
}
