﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

using Laboratorio;

namespace Laboratorio
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }       


        DataTable table = new DataTable();
        SqlConnection SqlConexion = new SqlConnection();
        

        private void btnClear_Click(object sender, EventArgs e)
        {
             txtNombre.Clear();
             txtPass.Clear();
            txtNombre.Focus();

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            DialogResult res;
            res = MessageBox.Show("Realmente Desea Salir del sistema?", "Salir de LabMECH", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                this.Show();
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {               
                SqlConexion.ConnectionString = DConexion.conexion; //utilizando la clase de conexion 
                
                //abriendo conexion
                SqlConexion.Open();
                

             


                // SqlCommand comando = new SqlCommand("select Nombre, Clave from Usuarios where Nombre = '" + txtNombre.Text + "'And clave = '" + txtPass.Text + "' ", SqlConexion);
                string Respuesta = "";

                SqlDataAdapter sda = new SqlDataAdapter("SELECT u.id_user, u.nombre, u.clave, u.id_dpto, d.Name, u.Codigo FROM [dbo].[Usuarios] u inner join [dbo].departamento d on d.id_dpto = u.id_dpto where u.Nombre ='" + txtNombre.Text + "' and u.clave ='" + txtPass.Text + "'", SqlConexion);

                DataTable dt = new DataTable();
                sda.Fill(dt);

                //if (dt.Rows[0][0].ToString() == "1")
                if (dt.Rows.Count == 1)

                {                    

                    Main frmPrincipal = new Main(dt.Rows[0][5].ToString() );
                    frmPrincipal.StartPosition = FormStartPosition.CenterScreen;
                    frmPrincipal.Show();//abriendo el formulario principal                 
                    this.Hide();//esto sirve para ocultar el formulario de login

                }
                //else { MessageBox.Show("Usuario y/o Password Incorrectos"); }
                else
                {
                    if (txtNombre.Text.Trim().Equals(""))
                    {
                        //MessageBox.Show("Enter Your Usuario to Login", "Empty Username", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        MessageBox.Show("Escriba el Usuario para Login");
                    }
                    else if (txtPass.Text.Trim().Equals(""))
                    {
                        //MessageBox.Show("Enter Your Password to Login", "Empty Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        MessageBox.Show("Por Favor escriba su Password para Login");
                    }
                    else
                    {
                        //MessageBox.Show("This Username Or Password Doesn't Exists", "Wrong Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        MessageBox.Show("El Usuario y/o Password No existen!");
                    }


                }

                SqlConexion.Close();

            }

            catch
            {

                if (table.Rows.Count <= 0)
                {
                    //panel1.Height = 0;
                    this.lblMensaje.ForeColor = Color.White;
                    lblMensaje.Text = "Usuario y/o Password Incorrectos";

                    this.txtPass.Focus();


                }

            }

            finally
            {
                //this.miConecion.Close();
            }

            table.Clear();
        }
    }
}
