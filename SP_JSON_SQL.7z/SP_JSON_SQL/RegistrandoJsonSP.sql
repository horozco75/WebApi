			
			DECLARE @json NVARCHAR(max)  = N'[
			{
			"Accion": "2",
			"IdActivo": "1",
			"IdPersonal": "5",
			"TipoMovimiento": "A",
			"FechaAsignacion": "2024-08-22T00:00:00",
			"EstadoActivo": "2",
			"Observaciones": "Esto es prueba desde SOAP",
			"IdRegion": "3",
			"IdUbicacion": "4",
			"RegistradoPor": "MGOMEZ",
			"IdPersonalDestino": "4"
			},
			{
			"Accion": "2",
			"IdActivo": "1",
			"IdPersonal": "5",
			"TipoMovimiento": "B",
			"FechaAsignacion": "2024-08-22T00:00:00",
			"EstadoActivo": "2",
			"Observaciones": "Esto es prueba desde SOAP",
			"IdRegion": "3",
			"IdUbicacion": "4",
			"RegistradoPor": "NOROZCO",
			"IdPersonalDestino": "4"
			}
			]';  
   
			INSERT INTO  [dbo].[RegMovimientos]  
			SELECT *   
			FROM OPENJSON(@json)  
			WITH (
			Accion  NVARCHAR(50) ' $.Accion',
			IdActivo  NVARCHAR(50) '$.IdActivo',    
			IdPersonal  NVARCHAR(50) '$.IdPersonal',
			TipoMovimiento  NVARCHAR(50) '$.TipoMovimiento',
			FechaAsignacion  NVARCHAR(50) '$.FechaAsignacion',
			EstadoActivo  NVARCHAR(50) '$.EstadoActivo',
			Observaciones  NVARCHAR(50) '$.Observaciones',
			IdRegion  NVARCHAR(50) '$.IdRegion',
			IdUbicacion  NVARCHAR(50) '$.IdUbicacion',
			RegistradoPor  NVARCHAR(50) '$.RegistradoPor',
			IdPersonalDestino  NVARCHAR(50) '$.IdPersonalDestino'
			)


			/******************* */
			SELECT * FROM [dbo].[RegMovimientos]