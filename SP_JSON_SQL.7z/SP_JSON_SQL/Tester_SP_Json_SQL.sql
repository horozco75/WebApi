		SELECT * FROM [dbo].[RegMovimientos]
		---------------------

		EXEC [dbo].[SP_InsertAssignmentDataJson] 
		N'[
			{
			"Accion": "2",
			"IdActivo": "1",
			"IdPersonal": "5",
			"TipoMovimiento": "A",
			"FechaAsignacion": "2024-08-23T00:00:00",
			"EstadoActivo": "2",
			"Observaciones": "Esto es prueba desde SQL TESTER",
			"IdRegion": "3",
			"IdUbicacion": "4",
			"RegistradoPor": "MACOSTA",
			"IdPersonalDestino": "4"
			},
			{
			"Accion": "2",
			"IdActivo": "1",
			"IdPersonal": "5",
			"TipoMovimiento": "B",
			"FechaAsignacion": "2024-08-23T00:00:00",
			"EstadoActivo": "2",
			"Observaciones": "Esto es prueba desde SQL TESTER",
			"IdRegion": "3",
			"IdUbicacion": "4",
			"RegistradoPor": "EGONZALEZ",
			"IdPersonalDestino": "4"
			}
			]';