USE [SARI]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE procedure [dbo].[SP_InsertAssignmentDataJson]
(
@json varchar(MAX)
)
AS
BEGIN
	SET dateformat dmy

			INSERT INTO  [dbo].[RegMovimientos]  
			SELECT *   
			FROM OPENJSON(@json)  
			WITH (
			Accion  NVARCHAR(50) ' $.Accion',
			IdActivo  NVARCHAR(50) '$.IdActivo',    
			IdPersonal  NVARCHAR(50) '$.IdPersonal',
			TipoMovimiento  NVARCHAR(50) '$.TipoMovimiento',
			FechaAsignacion  NVARCHAR(50) '$.FechaAsignacion',
			EstadoActivo  NVARCHAR(50) '$.EstadoActivo',
			Observaciones  NVARCHAR(50) '$.Observaciones',
			IdRegion  NVARCHAR(50) '$.IdRegion',
			IdUbicacion  NVARCHAR(50) '$.IdUbicacion',
			RegistradoPor  NVARCHAR(50) '$.RegistradoPor',
			IdPersonalDestino  NVARCHAR(50) '$.IdPersonalDestino'
			)

END
