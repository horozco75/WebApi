<?php
//$folder_path = '../img/ejemplos/'; 
//$folder_path = '../img/'; 
$folder_path = '../e07/img/'; 
$num_files = glob($folder_path . "*.{JPG,jpeg,gif,png,bmp}", GLOB_BRACE);
$folder = opendir($folder_path); 
if($num_files > 0){
 while(false !== ($file = readdir($folder)))  {
  $file_path = $folder_path.$file;
  $extension = strtolower(pathinfo($file ,PATHINFO_EXTENSION));
  if($extension=='jpg' || $extension =='png' || $extension == 'gif' || $extension == 'bmp') {
   ?>
    <img class="tfoto" style="max-width: 100px; max-height: 100px" src="
    <?php echo 
    $file_path;  //Original
    //$imagen = optimizar_imagen( $file_path, $destino, 40 );
    //$imagen = optimizar_imagen( $file_path, $destino, 40 );
    ?>" alt="Imagen de ejemplo" title="Imagen de ejemplo">
     <?php
  }}}
closedir($folder);


function optimizar_imagen($origen, $destino, $calidad) {
    $info = getimagesize($origen);
    if ($info['mime'] == 'image/jpeg'){
      $imagen = imagecreatefromjpeg($origen);
    }
    else if ($info['mime'] == 'image/gif'){
      $imagen = imagecreatefromgif($origen);
    }
    else if ($info['mime'] == 'image/png'){
      $imagen = imagecreatefrompng($origen);
    }
    
    imagejpeg($imagen, $destino, $calidad);
    
    return $destino;
    
}

?>   