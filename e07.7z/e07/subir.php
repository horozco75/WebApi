<?php

if (isset($_FILES['imagen'])){
	
	$cantidad= count($_FILES["imagen"]["tmp_name"]);
	
	for ($i=0; $i<$cantidad; $i++){
	//Comprobamos si el fichero es una imagen
	if ($_FILES['imagen']['type'][$i]=='image/png' || $_FILES['imagen']['type'][$i]=='image/jpeg'){
	
	//Subimos el fichero al servidor
	move_uploaded_file($_FILES["imagen"]["tmp_name"][$i], $_FILES["imagen"]["name"][$i]);
	$validar=true;
	}
	else $validar=false;	
	}
}

?>
<form method="post" action="?" enctype="multipart/form-data">
<input type="file" name="imagen[]" value="" multiple><br>

<input type="submit" value="Subir Imagen">
</form>


<?php if (isset($_FILES['imagen']) && $validar==true){ ?>
<?php $cantidad= count($_FILES["imagen"]["tmp_name"]);
	
	for ($i=0; $i<$cantidad; $i++){?>
<h1><?php echo $_FILES["imagen"]["name"][$i] ?></h1>
<img src="<?php echo $_FILES["imagen"]["name"][$i] ?>" width="100">
<?php } }?>