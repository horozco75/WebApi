<form action="guardarImagen.php" method="post" enctype="multipart/form-data">
  <ul>
      <li>
          <label>Elegir Imágen:</label>
          <input type="file" name="imagen" id="imagen"/>
      </li>
      <li>
          <input type="submit" name="submit" id="submit" />
      </li>
  </ul>
</form>