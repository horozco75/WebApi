<?php

//$target_dir = "../img/"; //directorio en el que se subira
$target_dir = "img/"; //directorio en el que se subira
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);//se añade el directorio y el nombre del archivo
$uploadOk = 1;//se añade un valor determinado en 1
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
$name_File= basename($_FILES["fileToUpload"]["name"]);//Tomamos el nombre del archivo.
$encriptar2=md5(basename($_FILES["fileToUpload"]["name"])).".".$imageFileType;/*En este caso lo encripté con md5, si quisiseras ponerle un nombre a tu elección puedes simplemente cambiar la variable y poner $encriptar="nombre a tú elección"*/
$resultado=$encriptar .".".$imageFileType;/*concatenamos el nuevo nombre con la extensión del archivo que está tomado mediante $imageFileType*/



if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
  //rename("../img/$name_File","../img/$encriptar2");//cambiamos el nombre del archivo mediante rename()
  rename("img/$name_File","img/$encriptar2");//cambiamos el nombre del archivo mediante rename()
    echo "El archivo ". basename( $_FILES["fileToUpload"]["name"]). " Se subio correctamente";
} else {
    echo "Error al cargar el archivo";
	}
}

?>