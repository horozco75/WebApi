<?php

function optimizar_imagen($origen, $destino, $calidad) {
      $info = getimagesize($origen);
      if ($info['mime'] == 'image/jpeg'){
        $imagen = imagecreatefromjpeg($origen);
      }
      else if ($info['mime'] == 'image/gif'){
        $imagen = imagecreatefromgif($origen);
      }
      else if ($info['mime'] == 'image/png'){
        $imagen = imagecreatefrompng($origen);
      }
      imagejpeg($imagen, $destino, $calidad);
      
      return $destino;
      $imagen = optimizar_imagen( $_FILES['imagen']['tmp_name'], $destino, 40 );
}

?>   