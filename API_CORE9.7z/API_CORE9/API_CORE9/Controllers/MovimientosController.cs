﻿using API_CORE9.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

using Newtonsoft.Json;

using API_CORE9.Repositorios.Contrato;
using Microsoft.EntityFrameworkCore;

namespace API_CORE9.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovimientosController : ControllerBase
    {
        private readonly ILogger<MovimientosController> _logger;

        private readonly IGenericRepository<Movimientos> _movimientosRepository;

        public MovimientosController(ILogger<MovimientosController> logger, IGenericRepository<Movimientos> movimientosRepository)
        {
            _logger = logger;
            _movimientosRepository = movimientosRepository;
        }

        [HttpGet]
        [Route("ListarJson")]
        public async Task<IActionResult> listaMovimientos()
        {
            List<Movimientos> _lista = await _movimientosRepository.Lista();
            var resultado = JsonConvert.SerializeObject(_lista);
            return StatusCode(StatusCodes.Status200OK, resultado);
        }

        [HttpGet]
        [Route("/Movimientos/{id}")]
        public async Task<IActionResult> GetById(int Id)
        {
            List<Movimientos> _lista = await _movimientosRepository.GetById(Id);
            var resultado = JsonConvert.SerializeObject(_lista);
            return StatusCode(StatusCodes.Status200OK, resultado);
        }


        [HttpPut]
        [Route("ModificarJson")]
        public async Task<IActionResult> editarMovJson([FromBody] Movimientos modelo)
        {
            bool _resultado = await _movimientosRepository.Editar(modelo);

            if (_resultado)
                return StatusCode(StatusCodes.Status200OK, new { valor = _resultado, msg = "ok" });
            else
                return StatusCode(StatusCodes.Status500InternalServerError, new { valor = _resultado, msg = "errror" });
        }

        [HttpPost]
        //[Route("/Movimientos/{Guardar}")]
        public async Task<IActionResult> guardarRegMov([FromBody] Movimientos modelo)
        {
            bool _resultado = await _movimientosRepository.Guardar(modelo);

            if (_resultado)
                return StatusCode(StatusCodes.Status200OK, new { valor = _resultado, msg = "ok" });
            else
                return StatusCode(StatusCodes.Status500InternalServerError, new { valor = _resultado, msg = "errror" });
        }



        [HttpPost]
        [Route("GuardarJson")]
        public async Task<IActionResult> guardarMovimientosJson(string modelo)
        {
            bool _resultado = await _movimientosRepository.GuardarJson(modelo);

            if (_resultado)
                return StatusCode(StatusCodes.Status200OK, new { valor = _resultado, msg = "ok" });
            else
                return StatusCode(StatusCodes.Status500InternalServerError, new { valor = _resultado, msg = "errror" });
        }

    }
}
