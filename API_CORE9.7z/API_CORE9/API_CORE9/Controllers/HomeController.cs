﻿using API_CORE9.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

using Newtonsoft.Json;

using API_CORE9.Repositorios.Contrato;
using Microsoft.EntityFrameworkCore;

namespace API_CORE9.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly IGenericRepository<Movimientos> _movimientosRepository;


        public HomeController(ILogger<HomeController> logger, IGenericRepository<Movimientos> movimientosRepository)
        {
            _logger = logger;
            _movimientosRepository = movimientosRepository;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> listaMovimientos()
        {
            List<Movimientos> _lista = await _movimientosRepository.Lista();
            var resultado = JsonConvert.SerializeObject(_lista);
            return StatusCode(StatusCodes.Status200OK, resultado);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


    }
}