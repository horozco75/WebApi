﻿namespace API_CORE9.Repositorios.Contrato
{
    public interface IGenericRepository<T> where T: class
    {
        Task<List<T>> Lista();
        Task<List<T>> GetById(int id);       
        Task<bool> Guardar(T modelo);
        Task<bool> Editar(T modelo);
        Task<bool> Eliminar(int id);
        Task<bool> GuardarJson(string modelo);
    }
}
