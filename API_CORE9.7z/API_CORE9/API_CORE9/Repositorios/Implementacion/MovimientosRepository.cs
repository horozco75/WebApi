﻿using API_CORE9.Models;
using API_CORE9.Repositorios.Contrato;
using System.Data;
using System.Data.SqlClient;

using Newtonsoft.Json;

namespace API_CORE9.Repositorios.Implementacion
{
    public class MovimientosRepository : IGenericRepository<Movimientos>  //Implementar Herencia
    {
        private readonly string _cadenaSQL = "";
        public MovimientosRepository(IConfiguration configuracion)
        {
            _cadenaSQL = configuracion.GetConnectionString("cadenaSQL");
        }

        public async Task<List<Movimientos>> Lista()
        {
            List<Movimientos> _lista = new List<Movimientos>();

            using (var conexion = new SqlConnection(_cadenaSQL))
            {
                conexion.Open();
                SqlCommand cmd = new SqlCommand("usp_listar_regmov", conexion);
                cmd.CommandType = CommandType.StoredProcedure;

                using (var dr = await cmd.ExecuteReaderAsync())
                {
                    while (await dr.ReadAsync())
                    {
                        _lista.Add(new Movimientos
                        {
                            idFila = Convert.ToInt32(dr["idFila"]),
                            Accion = dr["Accion"].ToString(),
                            //refDepartamento = new Departamento()
                            //{
                            //    idDepartamento = Convert.ToInt32(dr["idDepartamento"]),
                            //    nombre = dr["nombre"].ToString()
                            //},
                            //sueldo = Convert.ToInt32(dr["sueldo"]),
                            IdActivo = dr["IdActivo"].ToString(),
                            IdPersonal = dr["IdPersonal"].ToString(),
                            TipoMovimiento = dr["TipoMovimiento"].ToString(),
                            FechaAsignacion = dr["FechaAsignacion"].ToString(),
                            EstadoActivo = dr["EstadoActivo"].ToString(),
                            Observaciones = dr["Observaciones"].ToString(),
                            IdRegion = dr["IdRegion"].ToString(),
                            IdUbicacion = dr["IdUbicacion"].ToString(),
                            RegistradoPor = dr["RegistradoPor"].ToString(),
                            IdPersonalDestino = dr["IdPersonalDestino"].ToString(),                            
                        });
                    }
                }
            }
            return _lista;
        }

        public async Task<List<Movimientos>> GetById(int Id)
        {
            List<Movimientos> _lista = new List<Movimientos>();

            using (var conexion = new SqlConnection(_cadenaSQL))
            {
                conexion.Open();
                SqlCommand cmd = new SqlCommand("usp_obtener_regmov_byId", conexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", Id);

                using (var dr = await cmd.ExecuteReaderAsync())
                {
                    while (await dr.ReadAsync())
                    {
                        _lista.Add(new Movimientos
                        {
                            idFila = Convert.ToInt32(dr["idFila"]),
                            Accion = dr["Accion"].ToString(),                          
                            IdActivo = dr["IdActivo"].ToString(),
                            IdPersonal = dr["IdPersonal"].ToString(),
                            TipoMovimiento = dr["TipoMovimiento"].ToString(),
                            FechaAsignacion = dr["FechaAsignacion"].ToString(),
                            EstadoActivo = dr["EstadoActivo"].ToString(),
                            Observaciones = dr["Observaciones"].ToString(),
                            IdRegion = dr["IdRegion"].ToString(),
                            IdUbicacion = dr["IdUbicacion"].ToString(),
                            RegistradoPor = dr["RegistradoPor"].ToString(),
                            IdPersonalDestino = dr["IdPersonalDestino"].ToString(),
                        });
                    }
                }
            }
            return _lista;
        }
        public async Task<bool> Editar(Movimientos modelo)
        {
            using (var conexion = new SqlConnection(_cadenaSQL))
            {
                conexion.Open();
                SqlCommand cmd = new SqlCommand("sp_EditarRegMovimientos", conexion);
                cmd.Parameters.AddWithValue("idFila", modelo.idFila);
                cmd.Parameters.AddWithValue("Accion", modelo.Accion);                
                cmd.Parameters.AddWithValue("IdPersonal", modelo.IdPersonal);
                cmd.Parameters.AddWithValue("IdActivo", modelo.IdActivo);
                cmd.Parameters.AddWithValue("TipoMovimiento", modelo.TipoMovimiento);
                cmd.Parameters.AddWithValue("FechaAsignacion", modelo.FechaAsignacion);
                cmd.Parameters.AddWithValue("EstadoActivo", modelo.EstadoActivo);
                cmd.Parameters.AddWithValue("Observaciones", modelo.Observaciones);
                cmd.Parameters.AddWithValue("IdRegion", modelo.IdRegion);
                cmd.Parameters.AddWithValue("IdUbicacion", modelo.IdUbicacion);
                cmd.Parameters.AddWithValue("RegistradoPor", modelo.RegistradoPor);
                cmd.Parameters.AddWithValue("IdPersonalDestino", modelo.IdPersonalDestino);
                cmd.CommandType = CommandType.StoredProcedure;

                int filas_afectadas = await cmd.ExecuteNonQueryAsync();

                if (filas_afectadas > 0)
                    return true;
                else
                    return false;
            }
        }

        public async Task<bool> Eliminar(int id)
        {
            using (var conexion = new SqlConnection(_cadenaSQL))
            {
                conexion.Open();
                SqlCommand cmd = new SqlCommand("sp_EliminarEmpleado", conexion);
                cmd.Parameters.AddWithValue("idEmpleado", id);
                cmd.CommandType = CommandType.StoredProcedure;

                int filas_afectadas = await cmd.ExecuteNonQueryAsync();

                if (filas_afectadas > 0)
                    return true;
                else
                    return false;
            }
        }

        //public Task<List<Movimientos>> GetById(int id)
        //{
        //    throw new NotImplementedException();
        //}

        public async Task<bool> Guardar(Movimientos modelo)
        {
            using (var conexion = new SqlConnection(_cadenaSQL))
            {
                conexion.Open();
                SqlCommand cmd = new SqlCommand("sp_GuardarEmpleado", conexion);
                cmd.Parameters.AddWithValue("Accion", modelo.Accion);
                cmd.Parameters.AddWithValue("IdActivo", modelo.IdActivo);
                cmd.Parameters.AddWithValue("IdPersonal", modelo.IdPersonal);
                cmd.Parameters.AddWithValue("TipoMovimiento", modelo.TipoMovimiento);
                cmd.Parameters.AddWithValue("FechaAsignacion", modelo.FechaAsignacion);
                cmd.Parameters.AddWithValue("EstadoActivo", modelo.EstadoActivo);
                cmd.Parameters.AddWithValue("Observaciones", modelo.Observaciones);
                cmd.Parameters.AddWithValue("IdRegion", modelo.IdRegion);
                cmd.Parameters.AddWithValue("IdUbicacion", modelo.IdUbicacion);
                cmd.Parameters.AddWithValue("RegistradoPor", modelo.RegistradoPor);
                cmd.Parameters.AddWithValue("IdPersonalDestino", modelo.IdPersonalDestino);

                cmd.CommandType = CommandType.StoredProcedure;

                int filas_afectadas = await cmd.ExecuteNonQueryAsync();

                if (filas_afectadas > 0)
                    return true;
                else
                    return false;
            }
        }

        public async Task<bool> GuardarJson(string modelo)
        {
            using (var conexion = new SqlConnection(_cadenaSQL))
            {
                conexion.Open();
                SqlCommand cmd = new SqlCommand("sp_Insertassignment", conexion);
                cmd.Parameters.AddWithValue("json", "[" + modelo + "]");
                cmd.CommandType = CommandType.StoredProcedure;

                int filas_afectadas = await cmd.ExecuteNonQueryAsync();

                if (filas_afectadas > 0)
                    return true;
                else
                    return false;
            }
        }

         //nuevo
        public async Task<bool> Insert(Movimientos parameter)
        {

            using (SqlConnection sql = new SqlConnection(_cadenaSQL))
            {
                using (SqlCommand cmd = new SqlCommand("sp_insertpassenger", sql))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;

                    var json = JsonConvert.SerializeObject(parameter);
                    cmd.Parameters.Add(new SqlParameter("@json", json));

                    await sql.OpenAsync();
                    await cmd.ExecuteNonQueryAsync();
                    return;
                }
            }
        }


    }
}
