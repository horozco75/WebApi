﻿namespace API_CORE9.Models
{
    public class Movimientos
    {
        public int? idFila { get; set; }
        public string? Accion { get; set; }

        public string? IdActivo { get; set; }
        public string? IdPersonal { get; set; }
        public string? TipoMovimiento { get; set; }
        public string? FechaAsignacion { get; set; }
        public string? EstadoActivo { get; set; }
        public string? Observaciones { get; set; }
        public string? IdRegion { get; set; }
        public string? IdUbicacion { get; set; }
        public string? RegistradoPor { get; set; }
        public string? IdPersonalDestino { get; set; }

    }
}
